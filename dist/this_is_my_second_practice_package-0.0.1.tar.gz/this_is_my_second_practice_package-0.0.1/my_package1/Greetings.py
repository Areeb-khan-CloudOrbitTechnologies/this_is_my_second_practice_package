def greet(name):
    """This is greet function"""
    return f"Good day {name}"


print(greet("Areeb"))
